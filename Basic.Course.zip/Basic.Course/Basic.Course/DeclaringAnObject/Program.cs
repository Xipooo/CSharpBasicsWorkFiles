﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Basic.Course.CreatingAClass;

namespace Basic.Course.DeclaringAnObject
{
    static class Program
    {
        static void Main(string[] args)
        {
            MyClass MyObject = new MyClass();
        }
    }
}

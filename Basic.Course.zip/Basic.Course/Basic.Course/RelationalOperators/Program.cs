﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Basic.Course.RelationalOperators
{
    static class Program
    {
        static void Main(string[] args)
        {

            //Console.WriteLine(5 == 5);
            //Console.WriteLine(5 == 6);
            //Console.ReadLine();

            //Console.WriteLine(5 != 6);
            //Console.WriteLine(5 != 5);
            //Console.ReadLine();

            //Console.WriteLine(5 > 4);
            //Console.WriteLine(5 > 6);
            //Console.WriteLine(5 > 5);
            //Console.ReadLine();

            //Console.WriteLine(5 < 6);
            //Console.WriteLine(5 < 4);
            //Console.WriteLine(5 < 5);
            //Console.ReadLine();

            //Console.WriteLine(5 >= 4);
            //Console.WriteLine(5 >= 6);
            //Console.WriteLine(5 >= 5);
            //Console.ReadLine();

            //Console.WriteLine(5 <= 6);
            //Console.WriteLine(5 <= 4);
            //Console.WriteLine(5 <= 5);
            //Console.ReadLine();
        }
    }
}

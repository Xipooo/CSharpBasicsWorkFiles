﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Basic.Course.MathematicalOperators
{
    static class Program
    {
        static void Main(string[] args)
        {

            //int a = 10;
            //int b = 4;
            //int c;

            ////Addition
            //c = a + b;
            //Console.WriteLine(c);

            ////Subtraction
            //c = b - a;
            //Console.WriteLine(c);

            ////Multiply
            //c = a * b;
            //Console.WriteLine(c);

            ////Divide
            //c = b / a;
            //Console.WriteLine(c);

            ////Remainder
            //c = a % b;
            //Console.WriteLine(c);

            ////Same Data Types Only
            //int d = 10;
            //double e = 3;
            //int f;
            //f = d + e;
            //Console.WriteLine(f);

            Console.ReadLine();
        }
    }
}

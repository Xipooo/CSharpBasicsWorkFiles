﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Basic.Course.NumericDataTypes
{
    static class Program
    {
        static void Main(string[] args)
        {
            //string displayText = "Hello World!";
            //int displayInt = 23;
            double displayDouble = 25.003239834892374;

            Console.WriteLine(displayDouble);

            Debug.WriteLine(displayDouble);
            //Debug.WriteLine(displayInt.Count());
            Console.ReadLine();
        }
    }
}

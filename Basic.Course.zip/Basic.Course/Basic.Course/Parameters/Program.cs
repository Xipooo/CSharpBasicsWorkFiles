﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Basic.Course.Parameters
{
    static class Program
    {
        static void Main(string[] args)
        {

        }

        //private int AddTwoIntegers(int value1, int value2 = 10)
        //{
        //    int total = value1 + value2;
        //}
    }
}
